# Rhyan Martins — Running & Performance

Pacote inicial do site para continuar no Lovable.

## Arquivos

- `index.html`: site completo em uma página, com estilos e interações no próprio arquivo.
- `lovable-prompt.md`: instrução pronta para colar no Lovable junto com o `index.html`.

## Importante

As cinco fotos fornecidas para o hero, apresentação, cartões de corrida e chamada final estão incluídas como arquivos locais nesta pasta. As demais fotografias e as fontes são carregadas de serviços externos (Unsplash e Google Fonts), então precisam de internet para aparecer corretamente. O formulário é demonstrativo: não salva nem envia dados, não consulta agenda e não confirma horários. WhatsApp, disponibilidade, banco de dados, autenticação do painel e política de privacidade real ainda precisam ser configurados no Lovable antes de publicar.

O site não contém contatos, CREF, depoimentos ou resultados inventados.
